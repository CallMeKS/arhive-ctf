const express = require("express");
const path = require("path");
const fs = require("fs");
const app = express();

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "/html/index.html"));
});

app.get("/view", (req, res) => {
  let fileName = req.query.file;

  // Check if the requested file contains any directory traversal sequences
  if (
    fileName.includes("..\\") ||
    fileName.includes("../") ||
    fileName.includes("./") ||
    fileName.includes("/")
  ) {
    res.status(403).send("Access denied");
    return;
  }

  // URL-decode the filename to prevent percent-encoded path traversal
  fileName = decodeURIComponent(fileName);

  const filePath = path.join(__dirname, fileName);

  // Check if the requested file is a text file
  if (path.extname(filePath) !== ".txt") {
    res.status(403).send("Access denied");
    return;
  }

  // Check if the requested file exists
  if (!fs.existsSync(filePath)) {
    res.status(404).send("File not found");
    return;
  }

  // Read the contents of the file and send it to the client
  const fileContent = fs.readFileSync(filePath, "utf-8");
  res.send(fileContent);
});

app.listen(3000, () => {
  console.log("Server listening on port 3000");
});
