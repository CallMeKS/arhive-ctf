to build the docker file run command:
`docker build -t image-name .`

to run the docker file:
`docker run -p 5000:5000 image-name`
