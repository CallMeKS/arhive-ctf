from flask import Flask, request, render_template, send_file, flash
import os
import time
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('hello.html')

@app.route('/', methods=['POST'])
def upload_file():
    file = request.files['file']
    filename = file.filename

    # Check if the file is a .jpg file
    if not filename.endswith('.jpg'):
        return render_template('hello.html', error="Error: Only .jpg files are allowed.")

    file.save(os.path.join("static/uploads", filename))

    # Use exiftool to get metadata
    result = subprocess.run(['exiftool', '-Keywords', os.path.join("static/uploads", filename)], stdout=subprocess.PIPE)
    keyword = result.stdout.decode().strip().split(':')[-1].strip()

    # Resize the image using PIL
    from PIL import Image, ImageMath
    image = Image.open(os.path.join("static/uploads", filename))
    image = image.resize((150, 150))
    new_res = ImageMath.eval(keyword)
    image.save(os.path.join("static/uploads", "resized_" + filename))

    print("ImageMath.eval() output:", new_res)

    return render_template('hello.html', image_src="static/uploads/resized_" + filename, keyword=new_res)

@app.route("/download/<filename>")
def download_file(filename):
    return send_file(os.path.join("static/uploads", filename), as_attachment=True)

def empty_uploads():
    time.sleep(10)
    for filename in os.listdir("static/uploads"):
        os.remove(os.path.join("static/uploads", filename))

if __name__ == '__main__':
    app.run()
