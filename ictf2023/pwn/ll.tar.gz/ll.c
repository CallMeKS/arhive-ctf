#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int a = 1;
int b = 2;
int c = 3;
int d = -1337;
int e = 4;
int f = 5;
int g = 6;

typedef struct node {
  char name[8];
  int flags;
  struct node *next;
} node;

void win() { system("cat ./flag.txt"); }

void setup() {
  setvbuf(stdin, NULL, _IONBF, 0);
  setvbuf(stdout, NULL, _IONBF, 0);
  setvbuf(stderr, NULL, _IONBF, 0);
}

void menu() {
  puts("\n\nMenu");
  puts("====");
  puts("1. Print");
  puts("2. Next");
  puts("3. Edit");
  puts("4. Exit");
  return;
}

void print(node *ptr) {
  puts("\n\nPrint");
  puts("=====");
  printf("Name: %s\n", ptr->name);
  printf("Flags: %d\n", ptr->flags);
}

node *next(node *ptr) {
  puts("");
  return ptr->next;
}

void edit(node *ptr) {
  if (ptr->flags != -1337) {
    puts("You are not 1337 enough");
    return;
  }
  puts("\n\nEdit");
  puts("====");
  printf("Name: ");
  read(0, ptr->name, 24);
}

int main(void) {
  setup();
  node ll_1;
  node ll_2;
  node ll_3;
  node ll_4;

  ll_1.flags = 0;
  ll_2.flags = 0;
  ll_3.flags = 0;
  ll_4.flags = -1337;

  ll_1.next = &ll_2;
  ll_2.next = &ll_3;
  ll_3.next = &ll_4;
  ll_4.next = &ll_1;

  strcpy(ll_1.name, "ll_1");
  strcpy(ll_2.name, "ll_2");
  strcpy(ll_3.name, "ll_3");
  strcpy(ll_4.name, "ll_4");

  node *ptr = &ll_1;

  int option;
  do {
    option = 0;
    menu();
    printf("> ");
    scanf("%d", &option);
    switch (option) {
    case 1:
      print(ptr);
      break;
    case 2:
      ptr = next(ptr);
      break;
    case 3:
      edit(ptr);
      break;
    default:
      break;
    }
  } while (option >= 1 && option <= 3);

  if (a == 0xdeadbeef) {
    win();
  }
  return 0;
}
