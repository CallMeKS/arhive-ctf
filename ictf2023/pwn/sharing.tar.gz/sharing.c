#include <dlfcn.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define MAX_SIZE 65536

char bytes[MAX_SIZE];

void setup() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

void shared(char *filename) {
    char *error;
    void *handle = dlopen(filename, RTLD_LAZY);
    if (!handle) {
        fputs(dlerror(), stdout);
        exit(1);
    }

    dlerror();
    void (*fptr)();
    if (dlsym(handle, "load")) {
        if (dlsym(handle, "my")) {
            if (dlsym(handle, "func")) {
                if ((fptr = dlsym(handle, "please"))) {
                    (*fptr)();
                }
            }
        }
    }
    if ((error = dlerror()) != NULL) {
        fprintf(stdout, "%s\n", error);
        exit(EXIT_FAILURE);
    }
    dlclose(handle);
}

int main(void) {
    setup();
    char filename[] = "/tmp/a.so";

    int fd = open(filename, O_CREAT | O_WRONLY, 0777);
    puts("Data: ");
    int nbytes = read(0, bytes, MAX_SIZE);
    if (nbytes < 0) {
        puts("read error");
        exit(EXIT_FAILURE);
    }
    write(fd, bytes, nbytes);
    close(fd);
    shared(filename);
    return 0;
}
