#include <assert.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

void win() {
    int fd = open("./flag.txt", O_RDONLY);
    char buf[256];
    int nbytes = read(fd, buf, sizeof(buf));
    assert(nbytes > 0);
    write(1, buf, nbytes);
}

void getinput(uint32_t limit, uint32_t number, uint32_t size) {
    char buf[limit];
    int nbytes = read(0, buf, ((size_t)number * size) >> 32 | (number * size));
    assert(nbytes > 0);
}

void setup() {
    setvbuf(stdin, NULL, _IONBF, 0);
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stderr, NULL, _IONBF, 0);
}

int main(void) {
    setup();
    srand(time(NULL));
    uint32_t limit;
    do {
        limit = rand() & 0xff;
    } while (limit == 0);
    printf("You rolled %u as your maximum input size\n", limit);
    uint32_t number, size;
    printf("Number of boxes: ");
    scanf("%u", &number);
    assert(number > 0);
    printf("Size of each box: ");
    scanf("%u", &size);
    assert(size > 0);
    printf("You have chosen to input %u bytes\n", number * size);
    assert(number * size <= limit);
    getinput(limit + 8, number, size);
    return 0;
}
